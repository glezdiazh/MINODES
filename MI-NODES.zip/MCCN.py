# calculation of centralities

import time, datetime, os, sys, math
from string import *
from numpy import *
#from pylab import *
# from matplotlib.cbook import *
import networkx as nx
from math import *

# --------------------------------------------------------------
# FUNCTION definitions
# --------------------------------------------------------------
def unique(s):
    n = len(s)
    if n == 0:
        return []
    u = {}
    try:
        for x in s:
            u[x] = 1
    except TypeError:
        del u  # move on to the next method
    else:
        return u.keys()
    try:
        t = list(s)
        t.sort()
    except TypeError:
        del t  # move on to the next method
    else:
        assert n > 0
        last = t[0]
        lasti = i = 1
        while i < n:
            if t[i] != last:
                t[lasti] = last = t[i]
                lasti += 1
            i += 1
        return t[:lasti]
    # Brute force is all that's left.
    u = []
    for x in s:
        if x not in u:
            u.append(x)
    return u
# --------------------------------------------------------------
def printM(M):
    strM=''
    l=M.shape[0]
    c=M.shape[1]
    for ll in range(l):
        for cc in range(c):
            strM+=str(M[ll][cc])+"\t"
        strM+="\n"
    return strM
# --------------------------------------------------------------
def printM2(M):
    strM=''
    l=M.shape[0]
    c=M.shape[1]
    for ll in range(l):
        for cc in range(c):
            strM+=str(M[ll,cc])+"\t"
        strM+="\n"
    return strM
# --------------------------------------------------------------
def printV(M):
    strM=''
    l=len(M)
    for ll in range(l):
        strM+=str(M[ll])+" "
    strM+="\n"
    return strM
# --------------------------------------------------------------
def MPower(M,np): # power matrix
    nM=M.shape[0]
    if np==0: # zero power
        Mfin=identity(nM) # identity matrix
    if np==1:
        Mfin=M.copy()
    if np>1:  # non-zero power
        Mfin=M.copy()
        for npi in range(1,np):
            Mfin=dot(Mfin,M) # matrix multiplication matrixmultiply
    return Mfin
# --------------------------------------------------------------
def MatStd(M):
    for j in range(M.shape[1]):
        maxCol=float(abs(M[0][j]))
        for i in range(M.shape[0]):
            if abs(M[i][j])>maxCol:
                maxCol=abs(M[i][j])
        for i in range(M.shape[0]):
            if float(maxCol)!=0.0:
                M[i][j]=float(M[i][j])/float(maxCol)
            else:
                pass # print M[i][j] # to verfy the zero lines!
    return M
# --------------------------------------------------------------
def InverseElemets(M): # matrix with inverse elements (m-1)i
    Mt = zeros((M.shape[0],M.shape[0]))
    for l in range(M.shape[0]):
        for c in range(M.shape[1]):
            if M[l][c]!=0:
                Mt[l][c] = float(1)/float(M[l][c])
    return Mt
# --------------------------------------------------------------
def DegreeM(M): # j degree (outdegree for directed, degree for undirected)
    return sum(M,-1)-1 # due to 1 in diagonal
# --------------------------------------------------------------
def TotDegreeM(M): # degree matrix for asymetric graphs = max of sum along lines and columns
    return (sum(M)-1)+(sum(M,-1)-1) # due to 1 in diagonal
# --------------------------------------------------------------
def ProbVect(Pk,deg): # vector probabilities
##    print "*****CALCULATION OF ABSOLUT PROBABILITY VECTOR***"
##    print "Pk"
##    print printM(Pk)
##    print "sum(deg))",sum(deg)
##    print "deg"
##    print deg
    V=deg/sum(deg)# degree probability matrix

##    print "V"
##    print V
    
    vP=dot(Pk,V) # dot product of matrix V and vector M (matrixmultiply is faster than DOT)
##    print "vP"
##    print vP
##    print "****************************************************"

    return vP
# --------------------------------------------------------------
def ProbMat(M):          # P = matrix probabilities (Mij/sumMrow) = normalization!
    deg=sum(M,axis=1)
    n=M.shape[0]
    P=zeros((n,n)) # matrix probs
    for i in range(n):   # deg(i) is the i row elements sum as sum(M[:][i])
        if deg[i]>0: # posible 0 ?
            P[:][i]=M[:][i]/float(deg[i]) # each line divided by the corresponding line sum
        else:
            P[:][i]=M[:][i]*float(0) # possible ?
    return P
# --------------------------------------------------------------
def find_key(dic, val):
    # return the key of dictionary dic given the value
    for k, v in dic.iteritems():
        if v == val:
            return k
# -----------------------------------------------------------
def graph2adj(G):
    """Convert a networkX graph to an adjacency matrix and return both
    the matrix and a list which has IDs that correspond to the list
    indices."""
    nodes = {}
    names = G.nodes()
    n = len(names)
    adj = zeros((n,n), dtype='f')

    for i, name in enumerate(names): nodes[name] = i #make a names to indices dict
    for e in G.edges_iter():
        src, dst = nodes[e[0]], nodes[e[1]] # map endpoints to indices
        adj[src,dst] = 1                    # add indirected conectivities
        # adj[dst,src] = 1
    for i in range(n): adj[i,i] = 1         # add in self-loops
    return adj, names                       # return the mat and name list
# -----------------------------------------------------------
def adj2graph(adj, names):
    epsilon = epsilon = 1e-3
    """Given an adjacency matrix and a list of node IDs corresponding 
    to each column/row index, produce an undirected networkX graph."""
    G = nx.Graph()
    n = len(names)
    for i in range(n):
        for j in range(n):
            if adj[i,j] > epsilon: # all values not 1 are connections! no weights!
                G.add_edge(names[i], names[j])
    return G
# -----------------------------------------------------------
def ReadNet(filename):
    return nx.read_pajek(filename) # return graph G
# -----------------------------------------------------------
def ReadMat(filename): # loosing the weight!
    f = file(filename, "r") # read data as matrix
    adj = matrix([map(float,line.split()) for line in f])
    f.close()
    names=[]
    for i in range(adj.shape[0]):names.append("Node"+str(i+1)) # create node labels Nodei
    return adj2graph(adj, names) # return graph G
### -----------------------------------------------------------
##def ReadDat_old(filename):
##    f = file(filename, "r") # read data as list of pairs
##    PairList = [line.split() for line in f]
##    f.close()
##    G=nx.DiGraph() #create a directed graph
##    for Pair in PairList:
##        if len(Pair)!=0: #not empty line = no pair line
##            G.add_edge(Pair[0],Pair[1]) # add nodes to the graph
##    return G # return graph G
# -----------------------------------------------------------
def ReadDat(filename):
    G = nx.DiGraph()
    f = open(filename)
    for edge in f:              # each line corresponds to an edge
        src,dst = edge.split()  # edge source on left, destination on right
        G.add_edge(src,dst)     # add edge to graph
    f.close()
    return G # return graph G
# -----------------------------------------------------------
def ReadNetwork(datafile):
    extFile=datafile[-3:]
    flagFile=0
    if extFile=="net":
        G=ReadNet(datafile)
        flagFile=1
    if extFile=="mat":
        G=ReadMat(datafile)
        flagFile=1
    if extFile=="dat":
        G=ReadDat(datafile)
        flagFile=1
        
    if flagFile==0:
        print "Please use the net/mat/dat extensions for your file and retry."
        return # will raise an error!
    return G # return the graph of a NET, MAT, DAT file
### --------------------------------------------------------------
##def Mat_Labels2nxG(M,Labels): # transform a matrix and a dictionary with labels in a graph G in networkx
##    G=nx.DiGraph()
##    n=M.shape[0]
##    for i in range(n):
##        for j in range(n):
##            if M[i][j]==1: G.add_edge(Labels[i+1],Labels[j+1])
##    return G # return a graph
# --------------------------------------------------------------
def RemoveDisconnected(G):
    for node in G.nodes():
        if G.degree(node)==0: G.remove_node(node)
    return G
# --------------------------------------------------------------
def DistanceMatrix(G): # Distance matrix
    path_length=nx.all_pairs_shortest_path_length(G)
    nodes = {} # dictionary with nodes and index position
    names = G.nodes()
    for i, name in enumerate(names): nodes[name] = i #make a names to indices dict
    Dist=zeros((len(G),len(G)))
    for u,p in path_length.items():
        for v,d in p.items():
            Dist[nodes[u]][nodes[v]]=d
            Dist[nodes[v]][nodes[u]]=d
    return Dist
# --------------------------------------------------------------
def PairDistM(d,k): # pairs distance matrix, d=distance matrix, np=power matrix
    l=d.shape[0]
    dp=zeros((l,l)) # distances matrix
    for i in range(l):
        for j in range(l):
            if d[i,j]==k:
                dp[i,j]=k
            else:
                dp[i,j]=0.0
    return dp
#### ---------------------------------------------------------------------
#### MARKOV TIs
#### ---------------------------------------------------------------------

# P^k = MpN[k]= power of probability matrix
# each function return a list of TIs for each node for one k

# --------------------------------------------------------------
def MShEntropy(vP): # # return a list of Sh for each nodes pi*log(pi); P= probability vector
    MSh=[] # initialize the list with Sh variables
    for i in range(len(vP)):
        if vP[i] > 0:
            MSh.append(float(-vP[i]*log(vP[i])))
        else:
            MSh.append(float(0))
    return MSh # return a list of Sh for each nodes
### --------------------------------------------------------------
##def MTrace(M): # return the list of Pjj probabilities
##    MTr=[]
##    for j in range(M.shape[0]):
##        MTr.append(M[j][j])
##    return MTr
# --------------------------------------------------------------
def MTrace(M): # return the list of Pjj probabilities
    return list(M.diagonal())
# --------------------------------------------------------------
def MHararyNo(P,d): # Markov Harary number
    # P=probability matrix; for all i and one j
    MH=[]
    l=P.shape[0]
    for j in range(l):
        sumH=float(0)
        for i in range(l):
            if d[i][j] != 0: sumH+=float(P[i][j])/float(d[i][j])
        MH.append(float(sumH)/float(2.0))
    return MH
# --------------------------------------------------------------
def MWienerIndex(P,d):
    MW=[]
    l=P.shape[0]
    for j in range(l):
        W=float(0)
        for i in range(l):W+=d[i][j]*P[i][j]
        MW.append(W/float(2.0))
    return MW
# --------------------------------------------------------------
def MGutmanIndex(P,deg,d):
    MG=[]
    for j in range(len(deg)):
        nS6=float(0)
        for i in range(len(deg)):
            if d[i][j]!=0: nS6+=float(deg[i]*P[i][j])/float(d[i][j])
        MG.append(deg[j]*nS6)
    return MG
# --------------------------------------------------------------
def MSchultzIndex(P,deg,d):
    MS=[]
    for j in range(len(deg)):
        nS=float(0)
        for i in range(len(deg)):
            nS+=float(deg[i]+deg[j])*d[i][j]*P[i][j] # if P=d => classic TI
        MS.append(nS/float(2.0))
    return MS
# --------------------------------------------------------------
def MATS(k,P,d,deg):
    MA=[]
    l=len(deg)
    dp=PairDistM(d,k)# pair matrix
    for j in range(l):
        nATS=float(0)
        for i in range(l):
            if dp[i][j]!=0.: # if connected
                nATS+=float(dp[i][j]*P[i][j]*deg[i]*deg[j])
        MA.append(0.5*nATS)
    return MA
# --------------------------------------------------------------
def MBalaban(M,P,d):
    MB=[]
    l=d.shape[0]
    edges=float(sum(sum(M))-float(l)) # all connectivities minus the diagonal full of 1's
    for j in range(l):
        nBal=float(0)
        for i in range(l): # it is Ok because if i=j, i and j can not be bonded
            if M[i][j]!=0.0: #if i and j are bonded
                sumI=0.0
                sumJ=0.0
                for k in range(l):
                    sumI+=d[i][k]
                    sumJ+=d[k][j]
                if sumI!=0.0 and sumJ!=0.0:
                    nBal+=P[i][j]*math.sqrt(sumI*sumJ)
        MB.append(nBal*float(0.5*edges)/float(edges-l+2.)) #edges-l+1=the cyclomatic number of the molecular graph
    return MB
# --------------------------------------------------------------
def MRandic(M,deg,P): # npi= 1, if P=ones() => classical TI
    MR=[]
    l=M.shape[0]
    for j in range(l):
        nR=float(0.0)
        for i in range(l):
            if M[i][j]!=0: #if i and j are bonded; includes embeded
                if (deg[i]*deg[j])!=0:
                    nR+=P[i][j]/math.sqrt(deg[i]*deg[j])
        MR.append(nR/float(2.0))
    return MR
# --------------------------------------------------------------
def MKierHall(deg,vP): # d=dist, P=probability, npi= 0; if P=ones() => classical TI
    MK=[]
    nKH=float(0.0)
    for j in range(len(deg)):
        if deg[j]!=0:
            nKH=float(vP[j])/math.sqrt(deg[j])
        else:
            nKH=float(0.0)
        MK.append(nKH)
    return MK
# --------------------------------------------------------------
def MGalvesLike(P,deg,d):
    MG=[]
    n=d.shape[0] # nodes = i = j dimention
    CT=zeros((n,n))    
    Dinv_2 = d.copy() # Dinv_2 ij = 1/d-2 # initiated in d
    M=zeros((n,n))
    # calculate Dinv_2
    for l in range(n):
        for c in range(n):
            if d[l][c]!=0 and l!=c: Dinv_2[l][c] = float(1)/float(d[l][c]*d[l][c]) # the diagonal is the same of d
            if l==c: Dinv_2[l][c] = float(1) # diagonal of 1's if before errors (it should be 1 the distance i-i)
    # calculate M=P.Dinv_2
    M=dot(P,Dinv_2)
    for j in range(n):
        sumC=float(0)
        for i in range(n): # i<>j, 1/2 factor
            if i==j:
                CT[i][j]= deg[i]
            else:
                CT[i][j]= abs(M[i][j]-M[j][i])
            sumC+=CT[i][j] 
        MG.append(0.5*sumC)
    del M
    del Dinv_2
    return MG
# --------------------------------------------------------------
def MLeverge(P):
    ML=[]
    n=P.shape[0]
    nL=float(1) # 100 * Oij**0.5, n=node number, O=P*(Pt*P)*Pt, *=matrix multiplication
    O=zeros((n,n))
    # old formula error H=dot(dot(P,dot(transpose(P),P)),transpose(P)) # matrixmultiply/dot
    O=dot(P,dot(dot(transpose(P),P),transpose(P))) # matrixmultiply/dot
    for j in xrange(n):
        ML.append((O[j][j]**(float(1)/float(n)))*100.0)
    del O
    sys.exc_clear()
    sys.exc_traceback = sys.last_traceback = None
    return ML
# --------------------------------------------------------------
def MEcceentricity(vP,d):
    ME=[]
        
    for j in range(len(vP)):
        # create a list with distances not zero
        Mins=[]
        for dij in d[:,j]:
            if dij!=0:Mins.append(dij)
##        print "array(Mins)=",array(Mins)
##        print "max(array(Mins))=",max(array(Mins))
        ME.append(vP[j]/max(array(Mins)))
    return ME
# --------------------------------------------------------------
def MCloseness(vP,d): 
    MC=[]
    for j in range(len(vP)):
        if sum(d[:,j])!=0:
            MC.append(vP[j]/sum(d[:,j]))
        else:
            MC.append(0.)
    return MC
# --------------------------------------------------------------
def MRadiality(P,d):
    MR=[]
    n=P.shape[0]
    diameter=d.max() #diameter of the graph
    for j in range(n):
        sumR=float(0)
        for i in range(n):
            sumR+=(diameter+1-d[i][j])*P[i][j]
        MR.append(sumR/float(n-1))
    return MR
# --------------------------------------------------------------
def MCentroid(vP,deg):
    MC=[]
    n=len(vP)
    for j in range(n):
        Diffs=[]
        for i in range(n):
            Diffs.append(deg[i]*vP[i]-deg[j]*vP[j])
        MC.append(min(Diffs))
    return MC
# --------------------------------------------------------------
def MCF_Closeness(vP):
    MCFC=[]
    n=len(vP)
    for j in range(n):
        sumMC=float(0)
        for i in range(n):
            sumMC+=abs(vP[j]-vP[i])
        if sumMC!=0:
            MCFC.append(float(n-1)/sumMC)
        else:
            MCFC.append(0.)
    return MCFC
# --------------------------------------------------------------
def MBergaining(k,P):
    try:
        MB=[]
        n=P.shape[0]
        I=identity(n)
        u=ones((n))

##        print "===================================================="
##        print "P="
##        print P
##        print "u="
##        print u
##        print "dot(P,u)"
##        print dot(P,u)
##        print "abs(I-k*P)"
##        print abs(I-k*P)
##        print "linalg.inv(abs(I-k*P))"
##        print linalg.inv(abs(I-k*P))
##        print "dot(linalg.inv(abs(I-k*P)),dot(P,u))"
##        print dot(linalg.inv(abs(I-k*P)),dot(P,u))
##        print "(float(1)/float(k+1))"
##        print float(1)/float(k+1)
##        print "C=(float(1)/float(k+1))*dot(linalg.inv(abs(I-k*P)),dot(P,u))"
##        print (float(1)/float(k+1))*dot(linalg.inv(abs(I-k*P)),dot(P,u))
        
        C=(float(1)/float(k+1))*dot(linalg.inv(abs(I-k*P)),dot(P,u))
        for j in range(n):MB.append(C[j])
    except: #if error for singularity matrix, give zeros
        for j in range(n):MB.append(0.)
    return MB
# --------------------------------------------------------------
def MKatz(k,P):
    MK=[]
    n=P.shape[0]
    u=ones((n))
    C=zeros((n))
    for kk in range(0,k+1):
        C+=((float(1)/float(k+1))**kk)*dot(MPower(P.transpose(),kk),u) # add kk times the formula in vector Cj
    for j in range(n):MK.append(C[j])
    return MK
# --------------------------------------------------------------
def MCF_Betweeness(P):
    MCF_B=[]
    n=P.shape[0]
    f=float(1)/float((n-1)*(n-2))
    for j in range(n):
        sumMCF_B=float(0)
        for i in range(n):
            sumMCF_B+=P[i][j] 
        MCF_B.append(f*sumMCF_B)
    return MCF_B
# --------------------------------------------------------------
def MMarreroQ(P,deg): # if deg x P x deg = one value!
    MMQ=[]
    n=len(deg)
    XPdeg=dot(P,deg)
    for j in range(n):MMQ.append(deg[j]*XPdeg[j])
    return MMQ
# --------------------------------------------------------------
def MMarreroL(P,deg): # if deg x P x deg = one value!
    MML=[]
    n=len(deg)
    u=ones((n))
    XPdeg=dot(P,deg)
    for j in range(n):MML.append(u[j]*XPdeg[j])
    return MML
# --------------------------------------------------------------
def MMarreroMultiL(P,inDeg,outDeg): # if deg x P x deg = one value!
    MMmL=[]
    n=len(inDeg)
    XPdeg=dot(P,outDeg)
    for j in range(n):MMmL.append(inDeg[j]*XPdeg[j])
    return MMmL
# --------------------------------------------------------------
def MAvnirCi(P):
    MA=[]
    n=P.shape[0]
    U=ones((n,n))
    I=identity(n)
    W=P-(float(1)/float(n))*U
    U1=I*(-1.) # inversion symetry
    D1 = diag(dot(W.T,dot(I,dot(W,linalg.inv(I)))))    # 1st diagonal for the 1st trace
    D2 = diag(dot(W.T,dot(U1,dot(W,linalg.inv(U1)))))   # 2nd diagonal for the 2nd trace
    D3 = diag(dot(W.T,W))                               # 3th diagonal for the 3th trace
    for j in range(n):
        MA.append(float((float(1)/float(n))-D1[j]+D2[j])/float(2*sum(D3))) 
    return MA
# --------------------------------------------------------------
def MAvnirCx(P): 
    MA=[]
    n=P.shape[0]
    U=ones((n,n))
    I=identity(n)
    W=P-(float(1)/float(n))*U
    U2=zeros((n,n))
    # inverse diagonal = 1
    for i in range(n-1,-1,-1):
        U2[n-1-i][i]=1.0
    D1 = diag(dot(W.T,dot(I,dot(W,linalg.inv(I)))))    # 1st diagonal for the 1st trace
    D2 = diag(dot(W.T,dot(U2,dot(W,linalg.inv(U2)))))   # 2nd diagonal for the 2nd trace
    D3 = diag(dot(W.T,W))                               # 3th diagonal for the 3th trace
    for j in range(n):
        MA.append(float((float(1)/float(n))-D1[j]+D2[j])/float(2*sum(D3)))
        # MA.append(float(1.0-sum(D1)+sum(D2))/float(2*sum(D3))) 
    return MA
# --------------------------------------------------------------
def sortRank(M): # take a matrix/vector and return the list of indices of the ordered matrix by the first column!
    xlist=M.tolist()
    index=range(len(xlist))
    li_a=zip(xlist,index)
    li_a.sort()
    li_b=[(li_a[i][1],i) for i in index]
    li_b.sort()
    return [x[1] for x in li_b]
# --------------------------------------------------------------
def MDeg(vPk,deg):
    Degree=[] #matrix of node by power values of degrees
    for j in range(len(deg)):
        Degree.append(float(deg[j]*vPk[j])) # add to results
    return (Degree) # return the list of TIs
# --------------------------------------------------------------
def MinDeg(vPk,inDeg):
    Degree=[] #matrix of node by power values of degrees
    for j in range(len(inDeg)):
        Degree.append(float(inDeg[j]*vPk[j])) # add to results
    return (Degree) # return the list of TIs
# --------------------------------------------------------------
def MoutDeg(vPk,outDeg):
    Degree=[] #matrix of node by power values of degrees
    for j in range(len(outDeg)):
        Degree.append(float(outDeg[j]*vPk[j])) # add to results
    return (Degree) # return the list of TIs
# --------------------------------------------------------------
def MarkovRuckerIndex(P): #
    MR=[]
    l=P.shape[0]
    for j in range(l):
        W=float(0)
        for i in range(l):
            W=W+P[i][j]
        MR.append(W/float(2.0))
    return MR
# --------------------------------------------------------------
def MCCNmain(M,NodeList,deg,inDeg,outDeg,d,nTI,power):
    # M = connectivity matrix
    # NodeList = list with nodes = Node Labels
    # deg = node degree vector (in+out)
    # d = distance matrix
    # nTI = no. of TIs to be calculated
    # power = k power for Markov chains
    
    # open the output file
    # resFile="_Results_DETAILS.txt"
    # open the result files 
    # frFile = open(resFile,"a") # output file with all the results
    
    # POWER of M (conectivity matrix)
    kk=int(power)
    nNodes=M.shape[0] # no. of nodes

    # take the flags for the TIs
    [iSh,iTr,iH,iW,iS6,iS,iATS,iJ,iX1,iX,iG,iL,iRu,iDeg,iE,iCl,iR,iCen,iCFC,iB,iK,iCFB,iMMQ,iMML,iMMmL,iAIS]=nTI
    noTIs=0 # number of TIs
    if iSh==True: noTIs+=kk+2 # +1+1 = plus power 0+ non-Markov indices
    if iTr==True: noTIs+=kk+2
    if iH==True:  noTIs+=kk+2
    if iW==True:  noTIs+=kk+2
    if iS6==True: noTIs+=kk+2
    if iS==True:  noTIs+=kk+2
    if iATS==True:noTIs+=kk+2
    if iJ==True:  noTIs+=kk+2
    if iX1==True: noTIs+=kk+2
    if iX==True:  noTIs+=kk+2
    if iG==True:  noTIs+=kk+2
    if iL==True:  noTIs+=kk+2
    if iRu==True: noTIs+=kk+2
    if iDeg==True:
        noTIs+=kk+2 # total degrees (in+out)
        noTIs+=kk+2 # inDeg
        noTIs+=kk+2 # outDeg
    
    if iE==True:   noTIs+=kk+2
    if iCl==True:  noTIs+=kk+2
    if iR==True:   noTIs+=kk+2
    if iCen==True: noTIs+=kk+2
    if iCFC==True: noTIs+=kk+2
    if iB==True:   noTIs+=kk+2
    if iK==True:   noTIs+=kk+2
    if iCFB==True: noTIs+=kk+2
    if iMMQ==True: noTIs+=kk+2
    if iMML==True: noTIs+=kk+2
    if iMMmL==True:noTIs+=kk+2
    
    if iAIS==True:
        noTIs+=kk+2
        noTIs+=kk+2

    #########################################
    # MAIN calculation of node centralities #
    #########################################

    # each function of TIs calculate all the indices for one node! No sum for j
    # each TI depends on j=node and k=power
    
    # distance matrix
    #d=DistM(M)       # distance matrix

    # matrix Markov normalization: normalization of M -> power np -> trace of each
    NM=ProbMat(M)     # NM = normalized matrix = probabilities matrix

##    sText="M with weigths\n"+printM(M)+"\n"
##    print sText
##    sText="Probability matrix\n"+printM(NM)+"\n"
##    print sText
    # frFile.write(sText+"\n")
    
    
    # generate power of NM and the correspondent probability matrices
    MpN={}                   # list ? of matrices NM^k
    vP={}                    # list ? of probability vectors
    vPc=ProbVect(M,deg) # probability vector for non-Markov calculations = classical
    
    for k in range(kk+1):  # k=0...kk(power) for each power
        MpN[k]=MPower(NM,k)
##        sText="Probability matrix of order "+str(k)+"\n"+printM(MpN[k])+"\n"
##        print sText
        # frFile.write(sText+"\n")
        
        vP[k]=ProbVect(MpN[k],deg) # probability vector for each normalized matrix to power
##        sText="Absolute Probability Vector of order "+str(k)+"\n"+printV(vP[k])+"\n"
##        print sText
        # frFile.write(sText+"\n")
        
    ################
    # QSAR numbers #
    ################
    # flags: iSh,iTr,iH,iW,iS6,iS,iATS,iJ,iX1,iX,iG,iL,iDeg
    NDs=zeros((nNodes,noTIs)) # the output of this function= matrix nodesX TIs
    
    c=-1 # index for TIs along one row in NDs
    # Shannon Entropy indices (nSh)
    if iSh==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cSh in MShEntropy(vPc):
            inode=inode+1
            NDs[inode][c]=cSh # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MSh in MShEntropy(vP[k]):
                inode=inode+1
                NDs[inode][c]=MSh # add to results
        
    # Trace (nTr)
    if iTr==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cTr in MTrace(M):
            inode=inode+1
            NDs[inode][c]=cTr # add to results
            
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MTr in MTrace(MpN[k]):
                inode=inode+1
                NDs[inode][c]=MTr # add to results

    # Harary number (nH)
    if iH==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cH in MHararyNo(M,d):
            inode=inode+1
            NDs[inode][c]=cH # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MH in MHararyNo(MpN[k],d):
                inode=inode+1
                NDs[inode][c]=MH # add to results
    # Wiener index (nW)
    if iW==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cW in MWienerIndex(ones((nNodes,nNodes)),d):
            inode=inode+1
            NDs[inode][c]=cW # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MW in MWienerIndex(MpN[k],d):
                inode=inode+1
                NDs[inode][c]=MW # add to results
                
    # Gutman Index (nS6)
    if iS6==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cS6 in MGutmanIndex(ones((nNodes,nNodes)),deg,d):
            inode=inode+1
            NDs[inode][c]=cS6 # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MS6 in MGutmanIndex(MpN[k],deg,d):
                inode=inode+1
                NDs[inode][c]=MS6 # add to results  
    # Schultz Index (nS)
    if iS==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cS in MSchultzIndex(ones((nNodes,nNodes)),deg,d):
            inode=inode+1
            NDs[inode][c]=cS # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MS in MSchultzIndex(MpN[k],deg,d):
                inode=inode+1
                NDs[inode][c]=MS # add to results  
    # ATS (nATS)
    if iATS==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cAt in MATS(1,ones((nNodes,nNodes)),d,deg): # k =1
            inode=inode+1
            NDs[inode][c]=cAt # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MA in MATS(k,MpN[k],d,deg):
                inode=inode+1
                NDs[inode][c]=MA # add to results
    # Balaban
    if iJ==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cJ in MBalaban(M,M,d):
            inode=inode+1
            NDs[inode][c]=cJ # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MJ in MBalaban(M,MpN[k],d):
                inode=inode+1
                NDs[inode][c]=MJ # add to results 
    # Randic
    if iX1==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cX1 in MRandic(M,deg,M):
            inode=inode+1
            NDs[inode][c]=cX1 # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MX1 in MRandic(M,deg,MpN[k]):
                inode=inode+1
                NDs[inode][c]=MX1 # add to results
    # Kier-Hall
    if iX==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cK in MKierHall(deg,vPc):
            inode=inode+1
            NDs[inode][c]=cK # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MK in MKierHall(deg,vP[k]):
                inode=inode+1
                NDs[inode][c]=MK # add to results
    # Galves
    if iG==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cG in MGalvesLike(M,deg,d):
            inode=inode+1
            NDs[inode][c]=cG # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MG in MGalvesLike(MpN[k],deg,d):
                inode=inode+1
                NDs[inode][c]=MG # add to results  
    # Leverge
    if iL==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cL in MLeverge(M):
            inode=inode+1
            NDs[inode][c]=cL # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for ML in MLeverge(MpN[k]):
                inode=inode+1
                NDs[inode][c]=ML # add to results
    # Rucker
    if iRu==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cRu in MarkovRuckerIndex(M):
            inode=inode+1
            NDs[inode][c]=cRu # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MRu in MarkovRuckerIndex(MpN[k]):
                inode=inode+1
                NDs[inode][c]=MRu # add to results

    # Markov Degrees (MD)
    if iDeg==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cDeg in deg:
            inode=inode+1
            NDs[inode][c]=cDeg # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MDg in MDeg(vP[k],deg):
                inode=inode+1
                NDs[inode][c]=MDg # add to results
        # inDeg
        # classical indices
        c=c+1
        inode=-1 # node index
        for cinDeg in inDeg:
            inode=inode+1
            NDs[inode][c]=cinDeg # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MinDg in MinDeg(vP[k],inDeg):
                inode=inode+1
                NDs[inode][c]=MinDg # add to results
        # outDeg
        # classical indices
        c=c+1
        inode=-1 # node index
        for coutDeg in outDeg:
            inode=inode+1
            NDs[inode][c]=coutDeg # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MoutDg in MoutDeg(vP[k],outDeg):
                inode=inode+1
                NDs[inode][c]=MoutDg # add to results 

    # --------------------------------------
    # new indices
    # --------------------------------------
    
    # M-Eccentricity(vP,d)
    if iE==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cE in MEcceentricity(vPc,d):
            inode=inode+1
            NDs[inode][c]=cE # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for ME in MEcceentricity(vP[k],d):
                inode=inode+1
                NDs[inode][c]=ME # add to results
                
    # M-Closeness(vP,d)
    if iCl==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cCl in MCloseness(vPc,d):
            inode=inode+1
            NDs[inode][c]=cCl # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MCl in MCloseness(vP[k],d):
                inode=inode+1
                NDs[inode][c]=MCl # add to results
                
    # M-Radiality(P,d)
    if iR==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cR in MRadiality(M,d):
            inode=inode+1
            NDs[inode][c]=cR # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MR in MRadiality(MpN[k],d):
                inode=inode+1
                NDs[inode][c]=MR # add to results
    # M-Centroid(vP,deg)
    if iCen==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cCn in MCentroid(vPc,deg):
            inode=inode+1
            NDs[inode][c]=cCn # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MC in MCentroid(vP[k],deg):
                inode=inode+1
                NDs[inode][c]=MC # add to results
    # M-CF_Closeness(vP)
    if iCFC==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cCFC in MCF_Closeness(vPc):
            inode=inode+1
            NDs[inode][c]=cCFC # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MCFC in MCF_Closeness(vP[k]):
                inode=inode+1
                NDs[inode][c]=MCFC # add to results
    # M-Bergaining(k,P)
    if iB==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cBer in MBergaining(1,M): # k=1 as input
            inode=inode+1
            NDs[inode][c]=cBer # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MB in MBergaining(k,MpN[k]):
                inode=inode+1
                NDs[inode][c]=MB # add to results
    # M-Katz(k,P)
    if iK==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cKr in MKatz(1,M): # k=1 as input
            inode=inode+1
            NDs[inode][c]=cKr # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MK in MKatz(k,MpN[k]):
                inode=inode+1
                NDs[inode][c]=MK # add to results
    # M-CF_Betweeness(P)
    if iCFB==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cCFB in MCF_Betweeness(M): # k=1 as input
            inode=inode+1
            NDs[inode][c]=cCFB # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MCFB in MCF_Betweeness(MpN[k]):
                inode=inode+1
                NDs[inode][c]=MCFB # add to results
    # M-MarreroQ(P,deg)
    if iMMQ==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cMQ in MMarreroQ(M,deg): # k=1 as input
            inode=inode+1
            NDs[inode][c]=cMQ # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MMQ in MMarreroQ(MpN[k],deg):
                inode=inode+1
                NDs[inode][c]=MMQ # add to results
    # M-MarreroL(P,deg)
    if iMML==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cML in MMarreroL(M,deg): # k=1 as input
            inode=inode+1
            NDs[inode][c]=cML # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MML in MMarreroL(MpN[k],deg):
                inode=inode+1
                NDs[inode][c]=MML # add to results
                
    # M-Marrero multi L(P,inDeg,outDeg)
    if iMML==True:
        # classical indices
        c=c+1
        inode=-1 # node index
        for cMmuL in MMarreroMultiL(M,inDeg,outDeg): # k=1 as input
            inode=inode+1
            NDs[inode][c]=cMmuL # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MMmultiL in MMarreroMultiL(MpN[k],inDeg,outDeg):
                inode=inode+1
                NDs[inode][c]=MMmultiL # add to results
                
    # M-AvnirCi(P)
    if iAIS==True:
        # AIS
        # classical indices
        c=c+1
        inode=-1 # node index
        for cAIS in MAvnirCi(M): # k=1 as input
            inode=inode+1
            NDs[inode][c]=cAIS   # add to results
        # Markov indices
        for k in range(kk+1):   # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MAIS in MAvnirCi(MpN[k]):
                inode=inode+1
                NDs[inode][c]=MAIS # add to results

        # ARS
        # classical indices
        c=c+1
        inode=-1 # node index
        for cARS in MAvnirCx(M): # k=1 as input
            inode=inode+1
            NDs[inode][c]=cARS   # add to results
        # Markov indices
        for k in range(kk+1):  # k=0...kk(power) for each power
            c=c+1
            inode=-1 # node index
            for MARS in MAvnirCx(MpN[k]):
                inode=inode+1
                NDs[inode][c]=MARS # add to results 

    # delete variables to clean the memory
##    del deg
##    del NM
##    del MpN
##    del vP
##    sys.exc_clear()
##    sys.exc_traceback = sys.last_traceback = None

    # frFile.close()
    
    return NDs # return the list of TIs (maybe to add a list of TI labels)
